Markdown webdocs, docs-ru template, fork me!
=======
Шаблон для создания сайта с документацией, публикациями, Русский RU язык  

FAQ [Как создать новый раздел справки для своего аккаунта на GitHub](http://aplib.github.io/docs-ru/faq#создать-онлайн-справку-на-github)  
Статья на Хабре [Cистема подготовки веб-справки с использованием GitHub Pages](http://habrahabr.ru/post/205364/)  
Собственно этот сайт: [http://aplib.github.io/docs-ru](http://aplib.github.io/docs-ru)  
Базовый сайт проекта Markdown webdocs [http://aplib.github.io/markdown-site-template/](http://aplib.github.io/markdown-site-template/)  
